<?php
Configure::write('CakePluginTest.test_plugin.bootstrap', 'loaded plugin bootstrap');